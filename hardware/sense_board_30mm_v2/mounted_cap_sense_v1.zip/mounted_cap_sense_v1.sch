EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Connector:Conn_Coaxial J1
U 1 1 68019E44
P 2050 1800
F 0 "J1" H 2150 1775 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 1684 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 1800 50  0001 C CNN
F 3 " ~" H 2050 1800 50  0001 C CNN
	1    2050 1800
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J2
U 1 1 6802B178
P 2050 2150
F 0 "J2" H 2150 2125 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 2034 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 2150 50  0001 C CNN
F 3 " ~" H 2050 2150 50  0001 C CNN
	1    2050 2150
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J3
U 1 1 6802BA9A
P 2050 2500
F 0 "J3" H 2150 2475 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 2384 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 2500 50  0001 C CNN
F 3 " ~" H 2050 2500 50  0001 C CNN
	1    2050 2500
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J4
U 1 1 6802BF72
P 2050 2850
F 0 "J4" H 2150 2825 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 2734 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 2850 50  0001 C CNN
F 3 " ~" H 2050 2850 50  0001 C CNN
	1    2050 2850
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J5
U 1 1 6802C33E
P 2050 3200
F 0 "J5" H 2150 3175 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 3084 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 3200 50  0001 C CNN
F 3 " ~" H 2050 3200 50  0001 C CNN
	1    2050 3200
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J6
U 1 1 68034970
P 2050 3550
F 0 "J6" H 2150 3525 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 3434 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 3550 50  0001 C CNN
F 3 " ~" H 2050 3550 50  0001 C CNN
	1    2050 3550
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J7
U 1 1 68034976
P 2050 3900
F 0 "J7" H 2150 3875 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 3784 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 3900 50  0001 C CNN
F 3 " ~" H 2050 3900 50  0001 C CNN
	1    2050 3900
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial J8
U 1 1 6803497C
P 2050 4250
F 0 "J8" H 2150 4225 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 4134 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 4250 50  0001 C CNN
F 3 " ~" H 2050 4250 50  0001 C CNN
	1    2050 4250
	1    0    0    -1  
$EndComp
$Comp
L Connector:Conn_Coaxial JT
U 1 1 68034982
P 2050 4600
F 0 "JT" H 2150 4575 50  0000 L CNN
F 1 "Conn_Coaxial" H 2150 4484 50  0000 L CNN
F 2 "Connector_Huber:Huber_82_MMCX-50-0-8" H 2050 4600 50  0001 C CNN
F 3 " ~" H 2050 4600 50  0001 C CNN
	1    2050 4600
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR0101
U 1 1 68035149
P 2750 4800
F 0 "#PWR0101" H 2750 4550 50  0001 C CNN
F 1 "GND" H 2755 4627 50  0000 C CNN
F 2 "" H 2750 4800 50  0001 C CNN
F 3 "" H 2750 4800 50  0001 C CNN
	1    2750 4800
	1    0    0    -1  
$EndComp
Wire Bus Line
	2750 4800 2750 2000
Wire Wire Line
	2750 2000 2050 2000
Wire Wire Line
	2050 2350 2750 2350
Wire Wire Line
	2050 2700 2750 2700
Wire Wire Line
	2050 3050 2750 3050
Wire Wire Line
	2050 3400 2750 3400
Wire Wire Line
	2050 3750 2750 3750
Wire Wire Line
	2050 4100 2750 4100
Wire Wire Line
	2050 4450 2750 4450
Wire Wire Line
	2050 4800 2750 4800
$EndSCHEMATC
